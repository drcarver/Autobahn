﻿using Prism.Ioc;
using Prism.Modularity;

namespace Module
{
    public class MauiModule : IModule
    {
        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
        }

        public void OnInitialized(IContainerProvider containerProvider)
        {
        }
    }
}
