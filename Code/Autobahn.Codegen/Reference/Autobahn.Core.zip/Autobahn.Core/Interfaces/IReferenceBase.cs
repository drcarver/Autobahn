//***************************************************************************
//* DomainName: Core Interfaces
//* FileName:   IReferenceBase.cs
//***************************************************************************

public interface IReferenceBase
{
    Guid Id { get; set; }
    string Description { get; set; }
    string Code { get; set; }
    string Definition { get; set; }
    Guid? RefJurisdictionId { get; set; }
    decimal? SortOrder { get; set; }
}