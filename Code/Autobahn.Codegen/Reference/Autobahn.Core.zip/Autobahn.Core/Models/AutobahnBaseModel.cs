﻿//***************************************************************************
//* DomainName: Core Models
//* FileName:   AutobahnBaseModel.cs
//***************************************************************************

public partial class AutobahnBaseModel
{
    /// <summary>
    /// The Id of the Model
    /// </summary>
    [Key]
    public Guid Id { get; set; }
}
