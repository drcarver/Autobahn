//***************************************************************************
//* DomainName: Core Models
//* FileName:   ReferenceModel.cs
//***************************************************************************

public partial class ReferenceModel : IReferenceBase
{
    public Guid Id { get; set; }
    public string Description { get; set; }
    public string Code { get; set; }
    public string Definition { get; set; }
    public Guid? RefJurisdictionId { get; set; }
    public decimal? SortOrder { get; set; }
    public DateTime? RecordStartDateTime { get; set; }
    public DateTime? RecordEndDateTime { get; set; }
}
