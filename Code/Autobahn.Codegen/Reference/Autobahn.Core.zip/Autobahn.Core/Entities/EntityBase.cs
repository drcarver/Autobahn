﻿//***************************************************************************
//* DomainName: Core Entities
//* FileName:   EntityBase.cs
//***************************************************************************

public partial class EntityBase
{
    /// <summary>
    /// The Id of the Model
    /// </summary>
    [Key]
    public Guid Id { get; set; }
}
