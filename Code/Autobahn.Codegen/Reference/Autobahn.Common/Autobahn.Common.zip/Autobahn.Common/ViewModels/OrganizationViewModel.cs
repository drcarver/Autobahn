//**********************************************************
//* DomainName: Common Models
//* FileName:   OrganizationViewModel.cs
//***************************************************************************

namespace Autobahn.Common.ViewModels
{
    /// <summary>
    /// The Organization View Model
    /// </summary>
    public partial class OrganizationViewModel : ViewModelBase, Interfaces.IOrganization
    {
        /// <summary>
        /// Load the viewmodel from a model
        /// </summary>
        public void Load(Interfaces.IOrganization model)
        {
            IsBusy = true;
            Id = model.Id;
            _isChanged = false;
            IsNew = false;
            IsBusy = false;
        }
    }
}
