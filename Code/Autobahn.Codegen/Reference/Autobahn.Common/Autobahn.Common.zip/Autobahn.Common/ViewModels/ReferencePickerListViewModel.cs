﻿//**********************************************************
//* DomainName: Autobahn.Common
//* FileName:   ReferencePickList.cs
//**********************************************************

using System.Collections.ObjectModel;

namespace Autobahn.Common.ViewModels
{
    /// <summary>
    /// A pick list for reference lists
    /// </summary>
    public class ReferencePickList 
    {
        // protected member variable for Selected Item
        private ReferencePickListItemViewModel _selectedItem;

        // protected member variable for Title
        private string _title;

        /// <summary>
        /// The selected item from the list
        /// </summary>
        public ReferencePickListItemViewModel SelectedItem { get => _selectedItem; set => _selectedItem = value; }

        /// <summary>
        /// The title of the list
        /// </summary>
        public string Title { get => _title; set => _title = value; }

        /// <summary>
        /// The List of ReferencePickListItemViewModel
        /// </summary>
        public ObservableCollection<ReferencePickListItemViewModel> ReferenceList { get; set; }
    }
}
