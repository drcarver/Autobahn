﻿using System.Collections.ObjectModel;

namespace Autobahn.Common.ViewModels
{
    public class OrganizationPickList : PickListViewModel
    {
        public OrganizationPickList()
        {
            Title = "Organizations";
            ModelList = new ObservableCollection<PickListItemViewModel>
            {
                new PickListItemViewModel
                {
                    Description = "Autobahn To Learning", 
                    Id = Guid.Parse("{0C79BC1D-E4BF-4234-813F-0BEC9C903684}"),
                    SortOrder = Convert.ToDecimal("0.0")
                },
            }
            ;
        }
    }
}
