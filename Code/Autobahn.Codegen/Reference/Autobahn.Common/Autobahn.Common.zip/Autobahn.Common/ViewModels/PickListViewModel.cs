﻿//**********************************************************
//* DomainName: Autobahn.Common
//* FileName:   PickListViewModel.cs
//**********************************************************

using System.Collections.ObjectModel;

namespace Autobahn.Common.ViewModels
{
    /// <summary>
    /// A pick list for model lists
    /// </summary>
    public class PickListViewModel
    {
        // protected member variable for Selected Item
        private PickListItemViewModel _selectedItem;

        // protected member variable for Title
        private string _title;

        /// <summary>
        /// The selected item from the list
        /// </summary>
        public PickListItemViewModel SelectedItem { get => _selectedItem; set => _selectedItem = value; }

        /// <summary>
        /// The title of the list
        /// </summary>
        public string Title { get => _title; set => _title = value; }

        /// <summary>
        /// The List of PickListItemViewModel
        /// </summary>
        public ObservableCollection<PickListItemViewModel> ModelList { get; set; }
    }
}
