﻿using Autobahn.Common.ViewModels;
using System.Collections.ObjectModel;

namespace Autobahn.Common
{
    public static class SeedLists
    {
        /// <summary>
        /// The Seed Organizations
        /// </summary>
        public static ObservableCollection<OrganizationViewModel> Organizations = new ObservableCollection<OrganizationViewModel>
        {
            new OrganizationViewModel   // Autobahn
            {
                Id = Guid.Parse("{0C79BC1D-E4BF-4234-813F-0BEC9C903684}"),
            },
            new OrganizationViewModel   // Project Gutenberg
            {
                Id = Guid.Parse("{E32099B3-ED6D-4732-8CC6-E0F8E32C97BE}"),
            },
        };
        
        /// <summary>
        /// The Seed Organization Details
        /// </summary>
        public static ObservableCollection<OrganizationDetailViewModel> OrganizationDetails = new ObservableCollection<OrganizationDetailViewModel>
        {
            new OrganizationDetailViewModel
            {
                Id = Guid.Parse("{0C79BC1D-E4BF-4234-813F-0BEC9C903684}"),
                Name = "Autobahn To Learning",
                ShortName = "Autobahn",
                RefOrganizationTypeId = OrganizationDetailViewModel.RefOrganizationTypeList.FirstOrDefault(r => r.Code == "Publisher")?.Id
            },
            new OrganizationDetailViewModel
            {
                Id = Guid.Parse("{E32099B3-ED6D-4732-8CC6-E0F8E32C97BE}"),
                Name = "Project Gutenberg",
                ShortName = "Project Gutenberg",
                RefOrganizationTypeId = OrganizationDetailViewModel.RefOrganizationTypeList.FirstOrDefault(r => r.Code == "Library")?.Id
            },
        };
    }
}
